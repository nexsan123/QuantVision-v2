# Sprint 5: 因子验证 + 归因 + 冲突检测 (5天)

> **文档版本**: 1.0  
> **预计时长**: 5天  
> **前置依赖**: Sprint 4 完成  
> **PRD参考**: 4.3 因子有效性验证, 4.5 交易归因系统, 4.6 策略冲突检测  
> **交付物**: 因子验证面板、交易归因系统、冲突检测弹窗

---

## 目标

实现PRD中P0优先级的核心功能：因子有效性验证、交易归因系统、策略冲突检测

---

## Part A: 因子有效性验证系统 (2天)

### Task 5.1: 因子验证Schema (后端)

**文件**: `backend/app/schemas/factor_validation.py`

**核心模型**:
```python
class EffectivenessLevel(str, Enum):
    STRONG = "strong"      # IC_IR > 0.5, 多空收益差 > 10%
    MEDIUM = "medium"      # IC_IR > 0.3, 多空收益差 > 5%
    WEAK = "weak"          # IC_IR > 0.1, 多空收益差 > 2%
    INEFFECTIVE = "ineffective"

class FactorValidationResult(BaseModel):
    factor_id: str
    factor_name: str
    plain_description: str      # 大白话描述
    investment_logic: str       # 投资逻辑
    ic_stats: ICStatistics      # IC/IR统计
    return_stats: ReturnStatistics  # 收益统计
    is_effective: bool
    effectiveness_level: EffectivenessLevel
    suggested_combinations: list[str]  # 建议组合因子
    usage_tips: list[str]       # 使用建议
    risk_warnings: list[str]    # 风险提示
```

**验收标准**:
- [ ] 有效性等级分类合理
- [ ] 包含大白话描述字段
- [ ] 包含使用建议字段

---

### Task 5.2: 因子验证服务 (后端)

**文件**: `backend/app/services/factor_validation_service.py`

**核心功能**:
- IC/IR计算
- 分组收益统计
- 有效性判定
- 因子组合推荐

**有效性判定逻辑**:
```python
EFFECTIVENESS_THRESHOLDS = {
    "strong": {"ic_ir": 0.5, "spread": 0.10},
    "medium": {"ic_ir": 0.3, "spread": 0.05},
    "weak": {"ic_ir": 0.1, "spread": 0.02},
}
```

**验收标准**:
- [ ] IC/IR计算正确
- [ ] 有效性判定合理
- [ ] 大白话描述清晰

---

### Task 5.3: 因子验证API (后端)

**文件**: `backend/app/api/v1/factor_validation.py`

**端点**:
```
GET  /api/v1/factors/{id}/validation  - 获取验证结果
POST /api/v1/factors/{id}/validate    - 触发验证
POST /api/v1/factors/compare          - 因子对比
GET  /api/v1/factors/{id}/suggestions - 组合建议
```

---

### Task 5.4: 因子验证前端组件

**文件**: `frontend/src/components/Factor/FactorValidation.tsx`

**UI设计**:
```
┌─────────────────────────────────────────────────────┐
│ 🔬 PE_TTM 因子验证               [有效性: 中 ⭐⭐⭐] │
├─────────────────────────────────────────────────────┤
│ 📖 通俗解释                                         │
│ PE越低，说明股价相对于公司盈利越便宜。              │
│ 买入低PE股票，长期能获得超额收益。                  │
├─────────────────────────────────────────────────────┤
│ IC均值: 4.5%  │ IC_IR: 0.56  │ 多空收益差: 6.2%    │
├─────────────────────────────────────────────────────┤
│ 📈 IC时序图                                         │
│ [图表...]                                           │
├─────────────────────────────────────────────────────┤
│ 📊 分组收益                                         │
│ 第1组: 14.3% ████████████                          │
│ 第2组: 11.8% █████████                             │
│ 第3组:  9.5% ███████                               │
├─────────────────────────────────────────────────────┤
│ 💡 使用建议                                         │
│ - 该因子表现中等，建议与其他因子组合使用            │
│ - 推荐搭配: ROE, DIVIDEND_YIELD                     │
├─────────────────────────────────────────────────────┤
│                           [对比其他因子] [添加到策略]│
└─────────────────────────────────────────────────────┘
```

**验收标准**:
- [ ] 验证结果正确显示
- [ ] IC图表渲染正常
- [ ] 使用建议有价值

---

## Part B: 交易归因系统 (2天)

### Task 5.5: 交易记录和归因Schema (后端)

**文件**: 
- `backend/app/schemas/trade_record.py`
- `backend/app/schemas/attribution_report.py`

**核心功能**:
- 每笔交易自动记录
- 入场时因子值快照
- 入场时市场环境快照
- 自动触发归因分析

**自动触发条件**:
| 策略类型 | 触发条件 | 异常触发 |
|----------|----------|----------|
| 日内交易 | 每日或每50笔 | 单日亏损>2% |
| 短线 | 每周或每20笔 | 连续3笔亏损 |
| 中线 | 每月或每10笔 | 累计回撤>5% |
| 长线 | 每季度或每5笔 | 单笔亏损>3% |

---

### Task 5.6: 归因服务 (后端)

**文件**: `backend/app/services/attribution_service.py`

**核心功能**:
- 交易记录管理
- 归因报告生成
- AI诊断生成
- 模式识别

**AI诊断内容**:
```python
class AIDiagnosis(BaseModel):
    summary: str          # 诊断摘要
    strengths: list[str]  # 优势
    weaknesses: list[str] # 劣势
    suggestions: list[str] # 改进建议
    risk_alerts: list[str] # 风险提示
```

---

### Task 5.7: 归因API和前端

**API端点**:
```
GET  /api/v1/trades                   - 交易记录列表
GET  /api/v1/attribution/reports      - 归因报告列表
POST /api/v1/attribution/generate     - 手动触发归因
GET  /api/v1/attribution/diagnosis/{id} - AI诊断
```

**前端组件**:
- `components/Attribution/ReportPanel.tsx` - 归因报告面板
- `components/Attribution/AIDiagnosis.tsx` - AI诊断卡片

---

## Part C: 策略冲突检测系统 (1天)

### Task 5.8: 冲突检测Schema (后端)

**文件**: `backend/app/schemas/conflict.py`

**冲突类型**:
```python
class ConflictType(str, Enum):
    NO_CONFLICT = "no_conflict"        # 无冲突
    LOGIC_CONFLICT = "logic_conflict"  # 逻辑冲突: 同类策略相反信号
    EXECUTION_CONFLICT = "execution_conflict"  # 执行冲突: 不同类型策略
```

**超时设置**:
| 策略类型 | 超时时间 | 超时处理 |
|----------|:--------:|----------|
| 日内交易 | 1分钟 | 自动取消 |
| 短线策略 | 30分钟 | 自动取消 |
| 中长线 | 2小时 | 自动取消 |

---

### Task 5.9: 冲突服务和API (后端)

**文件**: 
- `backend/app/services/conflict_service.py`
- `backend/app/api/v1/conflict.py`

**核心功能**:
- 检测信号冲突
- 生成处理建议
- 管理超时

**API端点**:
```
GET  /api/v1/conflicts          - 冲突列表
GET  /api/v1/conflicts/pending  - 待处理冲突
POST /api/v1/conflicts/{id}/resolve - 解决冲突
```

---

### Task 5.10: 冲突弹窗组件 (前端)

**文件**: `frontend/src/components/Conflict/ConflictModal.tsx`

**UI设计**:
```
┌─────────────────────────────────────────────────────┐
│ ⚠️ 策略冲突待决策                   [逻辑冲突]      │
├─────────────────────────────────────────────────────┤
│ [进度条: 剩余 0:45]                                 │
├─────────────────────────────────────────────────────┤
│ ┌─────────────────┐  ┌─────────────────┐           │
│ │ 信号A           │  │ 信号B           │           │
│ │ AAPL            │  │ AAPL            │           │
│ │ 价值策略        │  │ 动量策略        │           │
│ │ 📈 买入         │  │ 📉 卖出         │           │
│ │ 信号强度: 85    │  │ 信号强度: 72    │           │
│ └─────────────────┘  └─────────────────┘           │
├─────────────────────────────────────────────────────┤
│ 💡 系统建议: 执行信号A (信号强度更高)               │
├─────────────────────────────────────────────────────┤
│ ○ 执行信号A (价值策略)                              │
│ ○ 执行信号B (动量策略)                              │
│ ○ 取消两个信号，观望                                │
├─────────────────────────────────────────────────────┤
│                          [稍后决定]  [确认执行]     │
└─────────────────────────────────────────────────────┘
```

**验收标准**:
- [ ] 冲突弹窗清晰
- [ ] 倒计时正确
- [ ] 决策选项完整

---

### Task 5.11: 路由注册

**修改文件**: `backend/app/main.py`

```python
from app.api.v1 import factor_validation, attribution, conflict

app.include_router(factor_validation.router, prefix=settings.API_V1_PREFIX)
app.include_router(attribution.router, prefix=settings.API_V1_PREFIX)
app.include_router(conflict.router, prefix=settings.API_V1_PREFIX)
```

---

## Sprint 5 完成检查清单

### 因子验证
- [ ] Schema定义完整
- [ ] IC/IR计算正确
- [ ] 大白话描述清晰
- [ ] 前端面板正常

### 交易归因
- [ ] 交易记录包含快照
- [ ] 归因报告自动生成
- [ ] AI诊断有价值
- [ ] 前端展示正常

### 冲突检测
- [ ] 冲突类型判定正确
- [ ] 超时自动处理
- [ ] 弹窗展示清晰
- [ ] 决策流程完整

---

## 新增API端点

```
# 因子验证
GET  /api/v1/factors/{id}/validation
POST /api/v1/factors/{id}/validate
POST /api/v1/factors/compare
GET  /api/v1/factors/{id}/suggestions

# 交易归因
GET  /api/v1/trades
GET  /api/v1/trades/{id}
GET  /api/v1/attribution/reports
POST /api/v1/attribution/generate
GET  /api/v1/attribution/diagnosis/{id}

# 冲突检测
GET  /api/v1/conflicts
GET  /api/v1/conflicts/pending
POST /api/v1/conflicts/{id}/resolve
```

---

## 下一步

完成后进入 **Sprint 6: 成本+模板+测试**

---

**预计完成时间**: 5天
